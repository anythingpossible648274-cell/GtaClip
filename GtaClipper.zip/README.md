# GTA Clipper

Android app (Kotlin, Jetpack Compose) that turns long gameplay videos into short clips
with hook titles and burned-in captions, all processed on the phone.

## Libraries and where they are used
| Library | License | Used in |
|---|---|---|
| yt-dlp | Unlicense | `python/downloader.py`, `Downloader.kt` (import from link) |
| Chaquopy | MIT | Gradle plugin, runs yt-dlp inside the app |
| Vosk | Apache 2.0 | `VoskTranscriber.kt` (offline captions), models via `ModelManager.kt` |
| AndroidX Media3 | Apache 2.0 | `ClipExporter.kt`, `ClipEffects.kt` (cut, 9:16, text overlays), player dialog |
| llama.cpp + GGUF | MIT | `LlamaViralScorer.kt` (see status below) |
| Jetpack Compose / AndroidX | Apache 2.0 | all UI |

## Pipeline (`Pipeline.kt`)
Import (link or file) -> audio-loudness candidates -> Vosk transcripts -> optional LLM ranking ->
cut + reframe + hook title + captions.

## Build
1. Android Studio (Koala+), JDK 17, and Python 3.8+ on your PATH (Chaquopy needs it to install yt-dlp).
2. Sync Gradle (needs internet), then Run on an arm64 phone or x86_64 emulator.
3. In the app: AI Models > Speech Captions > download a Vosk model to enable captions.

## Status / honest gaps
- Not compiled in the authoring environment (no Android SDK, no network): expect small fixes on first build.
- llama.cpp: the Kotlin side (model download, prompts, ranking) is done, but the native library
  `libllama_jni.so` is not bundled. Build llama.cpp with the NDK/CMake and expose
  `nativeLoad`, `nativeGenerate`, `nativeFree` (see `LlamaBridge`). Until then the app ranks by loudness.
- Model download URLs in `ModelManager.kt` should be checked before release.
- Blurred-background 9:16 layout is not implemented (clips are center-cropped).
- Only download videos you own or have permission to use.
